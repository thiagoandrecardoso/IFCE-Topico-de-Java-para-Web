package br.edu.ifce.primeiroJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimeiroJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiroJpaApplication.class, args);
	}

}
